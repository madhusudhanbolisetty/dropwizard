package com.maven;

import io.dropwizard.Configuration;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.dropwizard.db.DataSourceFactory;
import org.hibernate.validator.constraints.*;

import javax.validation.Valid;
import javax.validation.constraints.*;

public class manitaskConfiguration extends Configuration {
    // TODO: implement service configuration

    @Valid
    @NotNull
    private DataSourceFactory dataSourceFactory= new DataSourceFactory();

    @JsonProperty("database")
    public DataSourceFactory getDataSourceFactory(){
        return dataSourceFactory;
    }

    @JsonProperty("database")
    public void setDataSourceFactory(DataSourceFactory dataSourceFactory){
        this.dataSourceFactory=dataSourceFactory;
    }

}
