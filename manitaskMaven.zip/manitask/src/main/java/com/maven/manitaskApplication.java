package com.maven;

import com.maven.api.resources.LocationResources;
import com.maven.cli.services.LocationServices;
import com.maven.db.LocationDao;
import io.dropwizard.Application;
import io.dropwizard.jdbi.DBIFactory;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import org.skife.jdbi.v2.DBI;

public class manitaskApplication extends Application<manitaskConfiguration> {

    public static void main(final String[] args) throws Exception {
        new manitaskApplication().run(args);
    }

    @Override
    public String getName() {
        return "manitask";
    }

    @Override
    public void initialize(final Bootstrap<manitaskConfiguration> bootstrap) {
        // TODO: application initialization
    }

    @Override
    public void run(final manitaskConfiguration configuration,
                    final Environment environment) {
        // TODO: implement application

        final DBIFactory dbiFactory=new DBIFactory();
        final DBI dbi =dbiFactory.build(environment,configuration.getDataSourceFactory(),"mysql");

        final LocationDao locationDao=dbi.onDemand(LocationDao.class);
        final LocationServices locationServices=new LocationServices(locationDao);
        final LocationResources locationResources = new LocationResources(locationServices);
        environment.jersey().register(locationResources);
    }

}
