package com.maven.cli.services;

import com.maven.client.BaseEntity;
import com.maven.db.LocationDao;

import java.util.List;

public class LocationServices {

    private LocationDao locationDao;

    public LocationServices(final LocationDao locationDao){
        this.locationDao=locationDao;
    }
    public List<BaseEntity> getDetails(){
        return this.locationDao.getDetails();
    }
}
