package com.maven.db.utils;

import com.maven.client.BaseEntity;
import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class LocationMapper implements ResultSetMapper<BaseEntity> {
    @Override
    public BaseEntity map(int index, ResultSet r, StatementContext ctx) throws SQLException {

        BaseEntity baseEntity=new BaseEntity(
                r.getInt("id"),
                r.getString("name"),
                r.getString("branch")
        );

        return baseEntity;
    }

}
