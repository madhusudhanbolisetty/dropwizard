package com.maven.db;

import com.maven.client.BaseEntity;
import com.maven.db.utils.LocationMapper;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.customizers.RegisterMapper;

import java.util.List;
@RegisterMapper(LocationMapper.class)
public interface LocationDao {

    @SqlQuery("select * from `studentdetails`")
    public List<BaseEntity> getDetails();
}
