package com.test.mani.business.services;

import com.test.mani.db.LocationDao;
import com.test.mani.model.BaseEntity;

import java.util.List;

public class LocationServices {

    private LocationDao locationDao;

    public LocationServices(final LocationDao locationDao){
        this.locationDao=locationDao;
    }
    public List<BaseEntity> getDetails(){
        return this.locationDao.getDetails();
    }
}
