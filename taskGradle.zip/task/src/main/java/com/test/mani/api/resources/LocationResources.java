package com.test.mani.api.resources;


import com.test.mani.business.services.LocationServices;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/api/v1/details")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class LocationResources {

    private LocationServices locationservices;

    public LocationResources(final LocationServices locationservices){
        this.locationservices=locationservices;
    }
    @GET
    public Response getDetails(){
        return Response.ok().entity(this.locationservices.getDetails()).build();
    }
}
