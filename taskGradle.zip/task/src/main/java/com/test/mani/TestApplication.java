package com.test.mani;

import com.test.mani.api.resources.LocationResources;
import com.test.mani.business.services.LocationServices;
import com.test.mani.db.LocationDao;
import io.dropwizard.Application;
import io.dropwizard.Configuration;
import io.dropwizard.jdbi.DBIFactory;
import io.dropwizard.setup.Environment;
import org.skife.jdbi.v2.DBI;

public class TestApplication extends Application<TestConfiguration> {
      @Override
    public void run(TestConfiguration configuration, Environment environment) throws Exception{
          final DBIFactory dbiFactory=new DBIFactory();
          final DBI dbi =dbiFactory.build(environment,configuration.getDataSourceFactory(),"mysql");

          final LocationDao locationDao=dbi.onDemand(LocationDao.class);
          final LocationServices locationServices=new LocationServices(locationDao);
          final LocationResources locationResources = new LocationResources(locationServices);
    environment.jersey().register(locationResources);

}
public static void main(String args[]) throws Exception{
    new TestApplication().run(args);
}

}
