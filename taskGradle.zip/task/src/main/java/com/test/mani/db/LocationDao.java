package com.test.mani.db;


import com.test.mani.db.utils.LocationMapper;
import com.test.mani.model.BaseEntity;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.customizers.RegisterMapper;

import java.util.List;

@RegisterMapper(LocationMapper.class)
public interface LocationDao {

    @SqlQuery("select * from `studentdetails`")
    public List<BaseEntity> getDetails();

}
